j'aime le concept de spice of life mais il y a des choses que j'aimerais ajouter: 

Sleeping removes all your potion effects, including health boost.
Sleeping drains your hunger down to 3 haunches